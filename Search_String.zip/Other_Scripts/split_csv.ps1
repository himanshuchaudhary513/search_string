$file = "D:\Downloads\New_folder\crux-2023-12-top17m\crux-2023-12-top17m.csv"  # Replace with your file name
$chunkSize = 5MB          # Size of each split file (5 MB)
$outputDir = "D:\Downloads\New_folder\crux-2023-12-top17m\output"     # Output directory

# Ensure output directory exists
if (!(Test-Path $outputDir)) { New-Item -ItemType Directory -Path $outputDir }

# Initialize variables
$counter = 1
$currentFile = "$outputDir\part$counter.csv"
$currentSize = 0
$header = ""

# Process the CSV file line by line
Get-Content $file | ForEach-Object {
    if ($header -eq "") { 
        $header = $_ 
        # Write the header to the first file
        Add-Content $currentFile $header 
    } elseif ($currentSize -ge $chunkSize) {
        # Start a new file if size limit is reached
        $counter++
        $currentFile = "$outputDir\part$counter.csv"
        Add-Content $currentFile $header
        $currentSize = 0
    }
    # Add the line to the current file
    Add-Content $currentFile $_
    $currentSize += ($_.Length + 2)  # Approximate line size (includes CRLF)
}

Write-Host "CSV split completed. Files are in the '$outputDir' folder."
