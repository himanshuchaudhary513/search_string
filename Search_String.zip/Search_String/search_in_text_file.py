
import csv
import os

def search_string_in_text_file(input_file, search_string, output_file):
    try:
        with open(input_file, 'r', encoding='utf-8') as file, open(output_file, 'a', encoding='utf-8') as out_file:
            # Iterate over lines in the file
            for line in file:
                if search_string in line:
                    out_file.write(line)  # Write the matching line to the output file

        print(f"Scanning done for file : {input_file}.")
    
    except FileNotFoundError:
        print(f"The file '{input_file}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Input parameters
directory = r"D:\projects_2\Datasets\Top_SiteList_17_Million"  # Replace with the desired directory path (e.g., "/path/to/directory")
search_keyword = 'test'  #Replace with the string to search for
output_csv_file = 'Search_String\output\search_result_7.csv'  # Replace with your desired output file name

##search_string_in_csv(input_csv_file, search_keyword, output_csv_file)



all_listed_files=[]
try:
    #files = os.listdir(directory)  # Lists all files and directories
    for root, dirs, files in os.walk(directory):
        for listed_file in files:
            full_path = os.path.join(root, listed_file)
            all_listed_files.append(full_path)

    print("Files and directories in", directory, ":")
    for file in all_listed_files:
        ##print(file)
        file_name=f'{file}'
        search_string_in_text_file(file_name, search_keyword, output_csv_file)
    print(f"Search complete. Matches have been written to {output_csv_file}.")
except FileNotFoundError:
    print(f"The directory '{directory}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")
