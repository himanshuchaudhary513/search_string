file_path = "d:\Financial Aid.txt"  # Replace with your file's path

try:
    with open(file_path, "r") as file:  # Open the file in read mode
        content = file.read()           # Read the entire content of the file
        print(content)                  # Display the content
except FileNotFoundError:
    print(f"The file '{file_path}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")
