import os

directory = "d:/Downloads/New_folder/crux-2023-12-top17m/Top_SiteList_17_Million/21-40/"  # Replace with the desired directory path (e.g., "/path/to/directory")

try:
    files = os.listdir(directory)  # Lists all files and directories
    print("Files and directories in", directory, ":")
    for file in files:
        print(file)
except FileNotFoundError:
    print(f"The directory '{directory}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")
