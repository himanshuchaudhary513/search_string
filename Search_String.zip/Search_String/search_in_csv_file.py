
import csv
import os

def search_string_in_csv(input_file, search_string, output_file):
    try:
        with open(input_file, 'r', newline='', encoding='utf-8') as csv_file:
        ##with open('input_file', 'r') as csv_file:
            content = csv_file.read()
            if '\x00' in content:
                raise ValueError("File contains null bytes")
            reader = csv.reader(content.splitlines())
            
            # Write matching rows to the output file
            with open(output_file, 'a', newline='', encoding='utf-8') as out_file:
                writer = csv.writer(out_file)

                # Iterate through rows in the input file
                for row in reader:

                    # Check if search string exists in any cell of the row
                    if any(search_string in cell for cell in row):
                        writer.writerow(row)


        print(f"Search String from the file '{input_file}'.")
    except FileNotFoundError:
        print(f"The file '{input_file}' does not exist.")
    except ValueError as ve:
        print(f"An error occurred: {ve}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Input parameters
directory = "d:/Downloads/New_folder/crux-2023-12-top17m/Top_SiteList_17_Million/sample/"  # Replace with the desired directory path (e.g., "/path/to/directory")
search_keyword = ' 10'  #Replace with the string to search for
output_csv_file = r'D:\projects_2\Python_Project_1\output\search_result_5.csv'  # Replace with your desired output file name

##search_string_in_csv(input_csv_file, search_keyword, output_csv_file)



all_listed_files=[]
try:
    #files = os.listdir(directory)  # Lists all files and directories
    for root, dirs, files in os.walk(directory):
        for listed_file in files:
            full_path = os.path.join(root, listed_file)
            all_listed_files.append(full_path)

    print("Files and directories in", directory, ":")
    for file in all_listed_files:
        ##print(file)
        file_name=f'{file}'
        search_string_in_csv(file_name, search_keyword, output_csv_file)
except FileNotFoundError:
    print(f"The directory '{directory}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")
